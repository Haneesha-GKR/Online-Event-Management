var app = angular.module('myApp');

app.controller('shippingController',
    function ($scope, $rootScope, $localStorage, ajaxFactory, $location) {
        $scope.message = 'Everyone come and see how good I look!'
        $scope.customer = $localStorage.customer;
       
        $scope.goBackToProducts = function () {
            $location.path('/shopping/products');
        }
        $scope.setShipping = function () {
            ajaxFactory.ajaxCall('POST', '/customers/update/shipping',
                { updatedCart: $scope.customer.cart }).then(
                function (data, status, headers, config) {
                    $location.path('/shopping/billing');
                }, function (data, status, headers, config) {
                    $window.alert(data);
                });
        };

    }
);