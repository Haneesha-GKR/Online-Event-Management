var app = angular.module('myApp');

app.controller('orderController',
    function ($scope, $localStorage, $location, ajaxFactory) {
        $scope.orders = [];
        $scope.customer = $localStorage.customer;
        ajaxFactory.ajaxCall("GET", "/orders/get").then(
            function (response) {
                console.log(response);
                $scope.orders = response;
            },
            function (error) {
                $scope.orders = [];
                console.log(error);
            }
        );
        $scope.goBackToProducts = function () {
            $location.path('/shopping/products');
        }
        $scope.setProduct = function (productId) {
            $scope.product = this.product;
            $location.path('/shopping/products');
        };
    }
);