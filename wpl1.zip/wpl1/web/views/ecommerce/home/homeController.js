var app = angular.module('myApp');

app.controller('homeController',
    function ($scope, $rootScope, $localStorage) {
        $scope.user = $rootScope.currentUser || $localStorage.currentUser;
        
        $scope.scrollToTop = function(e){
            $("html, body").animate({ scrollTop: 0 }, "slow");
            return false;
        }
    }
);