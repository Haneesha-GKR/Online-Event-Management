var app = angular.module('myApp');

app.controller('shoppingController',
    function ($scope, $rootScope, $localStorage, $routeParams, $location, ajaxFactory) {
        $scope.scrollToTop = function(e){
            $("html, body").animate({ scrollTop: 0 }, "slow");
            return false;
        }
        $scope.setContent = function (file) {
            alert(file);
        }
        $scope.goBackToPage = function (page) {
            $location.path('/shopping/' + page);
        }
        $scope.shopping = $routeParams.id || "home";
        if (!$localStorage.customer) {
            ajaxFactory.ajaxCall("GET", "/customers/get").then(
                function (response) {
                    console.log(response);
                    $scope.customer = response;
                    $localStorage.customer = response;
                },
                function (error) {
                    $scope.customer = [];
                    console.log(error);
                }
            );
        }else{
            $scope.customer = $localStorage.customer;
        }
    }
);