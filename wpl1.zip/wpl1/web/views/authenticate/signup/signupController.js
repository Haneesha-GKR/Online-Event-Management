var app = angular.module('myApp');

app.controller('signupController',
    function ($scope, $rootScope, $timeout, ajaxFactory, $location) {
        $scope.notifyMssg = false;
        $scope.notifySuccess = false;
        $scope.notifyInfo = false;
        $scope.notifyWarning = false;
        $scope.notifyFailure = false;

        $scope.submitSignup = function () {
            var newUser = {
                username: $scope.username,
                password: $scope.password
            };
   
            ajaxFactory.ajaxCall("POST", '/user/signup', newUser).then(
                function(response) {
                    console.log(response);
                    $scope.notifyMssg = true;
                    $scope.notifySuccess = true;
                },
                function(error) {
                    console.log(error);
                    $scope.notifyMssg = true;
                    $scope.notifyFailure = true;
                }
            );
        }
    }
);