
var app = angular.module('myApp', ['ngRoute', 'ngCookies', 'ngStorage']);


app.config(function ($routeProvider) {
    $routeProvider

        // route for the index
        .when('/', {
            templateUrl: 'views/authenticate/signin/signin.html',
            controller: 'signinController'
        })

        // route for the index
        .when('', {
            templateUrl: 'views/authenticate/signin/signin.html',
            controller: 'signinController'
        })

        // route for the home page
        .when('/signin', {
            templateUrl: 'views/authenticate/signin/signin.html',
            controller: 'signinController'
        })

        // route for the about page
        .when('/signup', {
            templateUrl: 'views/authenticate/signup/signup.html',
            controller: 'signupController'
        })

        // route for the contact page
        .when('/shopping/:id', {
            templateUrl: 'views/ecommerce/shopping/shopping.html',
            controller: 'shoppingController'
        })

        //default condition
        .otherwise({
            redirectTo: '/signin'
        });

});
//https://stackoverflow.com/questions/11541695/redirecting-to-a-certain-route-based-on-condition
app.run(function ($rootScope, $cookies, $location) {
    if ($cookies.get('token') && $cookies.get('currentUser')) {
        $rootScope.token = $cookies.get('token');
        $rootScope.url = "http://localhost:5500"
    }
    $rootScope.$on("$locationChangeStart", function (event, next, current) {
        if (next.indexOf("signin") != -1 || next.indexOf("signup") != -1 ) {
            $cookies.remove("currentUser");
            $cookies.remove("token")
            $rootScope.token = $cookies.get('token');
        }else{
            //without authentication donot allow user to view his cart page
            if(!($rootScope.token)){
                $location.path( "/signin");
            }
        }
    });
});

//manual bootstrap process 
angular.element(document).ready(function () {
    angular.bootstrap(document, ['myApp']);
});