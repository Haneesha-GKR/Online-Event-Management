var express = require('express');
var MongoClient = require('mongodb').MongoClient;
var ObjectID = require('mongodb').ObjectID;
var bodyParser = require('body-parser');
var jwt = require('jwt-simple');
var bcrypt = require('bcryptjs');
var app = express();
var JWT_SECRET = 'hello';
var db = null;

MongoClient.connect("mongodb://localhost:27017/user", function (err, dbconn) {
    if (!err) {
        console.log("Connected");
        db = dbconn;
    }
});


MongoClient.connect("mongodb://localhost:27017/personal", function (err, dbconn) {
    if (!err) {
        console.log("Connected");
        db = dbconn;
    }
});

exports.signupUser = function (req, res) {
    db.collection('user', function (err, usersCollection) {

        bcrypt.genSalt(10, function (err, salt) {
            bcrypt.hash(req.body.password, salt, function (err, hash) {
                var newUser = {
                    username: req.body.username,
                    password: hash
                };
                usersCollection.insert(newUser, { w: 1 }, function (err) {
                    return res.send();
                });
            });
        });
    });
};

exports.loginUser = function (req, res) {

    db.collection('user', function (err, usersCollection) {
        usersCollection.findOne({ username: req.body.username }, function (err, user) {
            bcrypt.compare(req.body.password, user.password, function (err, result) {  
                console.log("credentials matched : "+result)              
                if (result) {
                    console.log("Sucess to get Data")
                    var token=jwt.encode(user,JWT_SECRET);
                    res.json({"token":token});
                } else {                    
                    console.log("error to get Data")
                    res.status(500).json({"error":"credentials mismatch"})
                }
            });
        });

        bcrypt.genSalt(10, function (err, salt) {
            bcrypt.hash(req.body.password, salt, function (err, hash) {
                var newUser = {
                    username: req.body.username,
                    password: hash
                };
                usersCollection.insert(newUser, { w: 1 }, function (err) {
                    res.send();
                });
            });

        });
    });
};
